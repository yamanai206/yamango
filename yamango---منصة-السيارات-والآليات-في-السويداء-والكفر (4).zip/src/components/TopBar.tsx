import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { 
  Menu, 
  X, 
  ShieldCheck, 
  Database, 
  Plus, 
  RefreshCw, 
  HelpCircle, 
  Languages, 
  ShoppingBag, 
  Wrench, 
  Building, 
  LayoutDashboard, 
  CheckCircle2, 
  MapPin, 
  SlidersHorizontal,
  Layers,
  ArrowLeft,
  UserCheck,
  Check,
  Sparkles,
  ExternalLink,
  BellRing,
  Bell,
  Package
} from 'lucide-react';

interface TopBarProps {
  currentUser: User;
  activeRole: UserRole;
  onSwitchRole: (role: UserRole) => void;
  activeTab: 'listings' | 'used_goods' | 'garages' | 'deals' | 'agents' | 'admin';
  setActiveTab: (tab: 'listings' | 'used_goods' | 'garages' | 'deals' | 'agents' | 'admin') => void;
  onOpenNewListing: () => void;
  onOpenSqlModal: () => void;
  onResetData: () => void;
  onOpenHelpCenter?: () => void;
  onOpenPushModal?: () => void;
  language?: 'ar' | 'en';
  onToggleLanguage?: () => void;
}

interface NavItemConfig {
  id: 'listings' | 'used_goods' | 'garages' | 'deals' | 'agents' | 'admin';
  title: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
  tag?: string;
}

const NAV_ITEMS: NavItemConfig[] = [
  {
    id: 'listings',
    title: 'سوق المركبات والآليات',
    subtitle: 'تصفح وشراء وتأجير الجرارات والحفارات والشاحنات والسيارات',
    icon: ShoppingBag,
    tag: 'السوق الرئيسي',
  },
  {
    id: 'used_goods',
    title: 'سوق المستعمل والأجهزة والأثاث',
    subtitle: 'أدوات منزلية، أثاث، إلكترونيات، طاقة شمسية، ودفع عبر الوكلاء بالضمان',
    icon: Package,
    tag: 'سوق المستعمل',
  },
  {
    id: 'garages',
    title: 'الكراجات المعتمدة والفحص الفني',
    subtitle: 'حجز مواعيد المعاينة الميدانية وتقارير السلامة ومطابقة المواصفات',
    icon: Wrench,
    tag: 'فحص معتمد',
  },
  {
    id: 'deals',
    title: 'الصفقات والوساطة المالية (الإسكرو)',
    subtitle: 'متابعة العقود الرقمية، حجز العربون، ورموز التحقق السرية OTP',
    icon: ShieldCheck,
    tag: 'حماية إسكرو',
  },
  {
    id: 'agents',
    title: 'وكلاء الدفع المعتمدون',
    subtitle: 'نقاط تسليم واستلام الكاش المعتمدة في الكفر والسويداء وصلخد',
    icon: Building,
    tag: 'نقاط الكاش',
  },
  {
    id: 'admin',
    title: 'لوحة تحكم المشرف العام',
    subtitle: 'مراقبة الصفقات، نمو المبيعات، المخططات البيانية، وضبط العملات',
    icon: LayoutDashboard,
    tag: 'الإدارة العليا',
  },
];

const ROLES_CONFIG: {
  role: UserRole;
  title: string;
  desc: string;
  badge: string;
}[] = [
  {
    role: 'buyer',
    title: 'مشتري / مستأجر',
    desc: 'تصفح الآليات، تقديم العروض، إيداع العربون، وحجز الفحص',
    badge: 'طلب وشراء',
  },
  {
    role: 'seller',
    title: 'بائع / مؤجّر',
    desc: 'إضافة الإعلانات، إدارة الأسعار وتتبع العروض وتوقيع العقود',
    badge: 'عرض وبيع',
  },
  {
    role: 'garage',
    title: 'كراج فني معتمد',
    desc: 'إصدار تقارير الفحص الفني وتوثيق حالة المحرك والشاسيه',
    badge: 'فحص ميكانيكي',
  },
  {
    role: 'agent',
    title: 'وكيل دفع (إسكرو)',
    desc: 'تأكيد استلام العربون بالكاش وفتح رموز التحقق OTP وإصدار الإيصالات',
    badge: 'وساطة كاش',
  },
  {
    role: 'admin',
    title: 'مشرف المنصة العام',
    desc: 'إدارة شاملة لكافة الصفقات، إشغال الكراجات، العمولات وأسعار الصرف',
    badge: 'إشراف كامل',
  },
];

export const TopBar: React.FC<TopBarProps> = ({
  currentUser,
  activeRole,
  onSwitchRole,
  activeTab,
  setActiveTab,
  onOpenNewListing,
  onOpenSqlModal,
  onResetData,
  onOpenHelpCenter,
  onOpenPushModal,
  language = 'ar',
  onToggleLanguage,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Close drawer on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMenuOpen(false);
      }
    };
    if (isMenuOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMenuOpen]);

  // Prevent background scroll when drawer is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  const activeNav = NAV_ITEMS.find((n) => n.id === activeTab) || NAV_ITEMS[0];
  const ActiveNavIcon = activeNav.icon;

  const handleSelectTab = (tabId: 'listings' | 'used_goods' | 'garages' | 'deals' | 'agents' | 'admin') => {
    setActiveTab(tabId);
    setIsMenuOpen(false);
  };

  const handleSelectRole = (role: UserRole) => {
    onSwitchRole(role);
  };

  return (
    <>
      {/* Sleek, Distinctive Top Header */}
      <header className="sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Top Corner: Distinctive Menu Launcher Button */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsMenuOpen(true)}
                aria-expanded={isMenuOpen}
                aria-label="فتح قائمة الخيارات والصفحات"
                className="relative group flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700/90 text-white border border-slate-700/80 shadow-xs transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                title="اضغط لفتح قائمة الخيارات والتنقل بين أقسام المنصة"
              >
                <div className="w-8 h-8 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors">
                  <Menu className="w-4 h-4 transition-transform group-hover:scale-110" />
                </div>
                <div className="text-right hidden sm:block">
                  <span className="text-xs font-black block leading-tight text-white group-hover:text-amber-300 transition-colors">
                    قائمة الخيارات
                  </span>
                  <span className="text-[10px] text-slate-400 block font-normal leading-tight">
                    أقسام المنصة والأدوار
                  </span>
                </div>
                {/* Active indicator dot */}
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </button>

              {/* Brand Wordmark & Local Tag */}
              <button
                type="button"
                onClick={() => handleSelectTab('listings')}
                className="flex items-center gap-2 text-right group focus:outline-none cursor-pointer"
              >
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-500 text-slate-950 flex items-center justify-center font-black text-base shadow-sm shadow-amber-600/30 group-hover:scale-105 transition-transform">
                  y
                </div>
                <div className="leading-tight">
                  <span className="text-lg font-black tracking-tight text-white group-hover:text-amber-400 transition-colors">
                    yamango
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium block">
                    السويداء · الكفر
                  </span>
                </div>
              </button>
            </div>

            {/* Center: Desktop Navigation Hub */}
            <div className="hidden md:flex items-center gap-1 bg-slate-800/80 p-1 rounded-2xl border border-slate-700/60">
              <button
                type="button"
                onClick={() => handleSelectTab('listings')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'listings'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                سوق الآليات
              </button>
              <button
                type="button"
                onClick={() => handleSelectTab('used_goods')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'used_goods'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <Package className="w-3.5 h-3.5 text-amber-400" />
                <span>سوق المستعمل</span>
                <span className="text-[9px] bg-amber-400/20 text-amber-300 px-1.5 py-0.2 rounded-full font-bold">
                  جديد
                </span>
              </button>
              <button
                type="button"
                onClick={() => handleSelectTab('garages')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'garages'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                الكراجات
              </button>
              <button
                type="button"
                onClick={() => handleSelectTab('deals')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'deals'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                الصفقات
              </button>
              <button
                type="button"
                onClick={() => handleSelectTab('agents')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'agents'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                الوكلاء
              </button>
            </div>

            {/* Left Corner: Quick Actions */}
            <div className="flex items-center gap-2">
              {/* Primary Action Button */}
              <button
                type="button"
                onClick={onOpenNewListing}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 rounded-xl transition-all shadow-sm shadow-amber-500/20 whitespace-nowrap cursor-pointer hover:shadow-md"
                title="إضافة إعلان بيع أو إيجار جديد"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span className="hidden sm:inline">أضف إعلانك</span>
                <span className="sm:hidden">إعلان</span>
              </button>

              {/* Push Notifications Button */}
              {onOpenPushModal && (
                <button
                  type="button"
                  onClick={onOpenPushModal}
                  className="relative flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer"
                  title="تنبيهات الصفقات الفورية بالمتصفح (Push Notifications)"
                >
                  <BellRing className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden lg:inline text-[11px]">الإشعارات</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </button>
              )}

              {/* Language Switcher */}
              {onToggleLanguage && (
                <button
                  type="button"
                  onClick={onToggleLanguage}
                  className="flex items-center gap-1 px-2.5 py-2 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer"
                  title={language === 'ar' ? 'التبديل إلى English' : 'التبديل إلى العربية'}
                >
                  <Languages className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-mono text-[11px] font-black">{language === 'ar' ? 'EN' : 'عربي'}</span>
                </button>
              )}

              {/* Help Center Shortcut */}
              {onOpenHelpCenter && (
                <button
                  type="button"
                  data-testid="help-center-btn"
                  onClick={onOpenHelpCenter}
                  className="hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer"
                  title="مركز المساعدة ودليل المستخدم والدعم الفني"
                >
                  <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>المساعدة</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Bespoke Corner Slide-out Menu / Options Hub Drawer */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop Blur Overlay */}
          <div
            onClick={() => setIsMenuOpen(false)}
            className="fixed inset-0 bg-slate-950/75 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
          />

          {/* Drawer Panel Container (Anchored at top corner in RTL) */}
          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10 sm:pl-16">
            <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200 ease-out text-slate-900">
              
              {/* Drawer Top Header */}
              <div className="p-5 bg-gradient-to-l from-slate-900 via-slate-900 to-slate-950 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-500 text-slate-950 flex items-center justify-center font-black text-lg shadow-md shadow-amber-500/20">
                    y
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-black tracking-tight text-white">yamango</span>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded-full border border-amber-500/30">
                        منصة وساطة معتمدة
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      محافظة السويداء · مركز الانطلاق: بلدة الكفر
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsMenuOpen(false)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="إغلاق القائمة (Esc)"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Drawer Body */}
              <div className="flex-1 overflow-y-auto p-5 space-y-6">
                
                {/* User Session Profile Card */}
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>الحساب النشط</span>
                    </span>
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-md border border-emerald-200">
                      موثق إسكرو
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-black text-slate-900">{currentUser.fullName}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        بلدة الكفر · {currentUser.phone}
                      </p>
                    </div>
                    <div className="text-left">
                      <span className="text-[11px] font-mono font-bold text-slate-700 block">
                        التقييم: ★ {currentUser.ratingAvg}
                      </span>
                      <span className="text-[10px] text-slate-500 block">
                        {currentUser.dealsCompletedCount} صفقات ناجحة
                      </span>
                    </div>
                  </div>
                </div>

                {/* Section 1: Main Platform Navigation */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <SlidersHorizontal className="w-3.5 h-3.5 text-amber-600" />
                      <span>أقسام المنصة والصفحات الرئيسية</span>
                    </h3>
                    <span className="text-[10px] text-slate-400 font-bold">5 أقسام</span>
                  </div>

                  <div className="space-y-2">
                    {NAV_ITEMS.map((item) => {
                      const Icon = item.icon;
                      const isActive = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleSelectTab(item.id)}
                          className={`w-full text-right p-3.5 rounded-2xl border transition-all flex items-start gap-3 cursor-pointer ${
                            isActive
                              ? 'bg-amber-500/10 border-amber-400 shadow-xs'
                              : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <div
                            className={`p-2 rounded-xl shrink-0 ${
                              isActive
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            <Icon className="w-4 h-4" />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <span
                                className={`text-xs font-black truncate ${
                                  isActive ? 'text-amber-950 font-bold' : 'text-slate-900'
                                }`}
                              >
                                {item.title}
                              </span>
                              {isActive && (
                                <span className="text-[10px] bg-amber-600 text-white font-black px-2 py-0.5 rounded-md shrink-0">
                                  القسم الحالي
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed line-clamp-2">
                              {item.subtitle}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Section 2: Role Simulation Switcher */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                      <span>محاكاة الدور والصلاحيات</span>
                    </h3>
                    <span className="text-[10px] text-slate-500">
                      الدور الفعلي: <strong className="text-slate-800 font-bold">{activeRole}</strong>
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 mb-2.5">
                    اختر الدور لتجربة كامل واجهات وصلاحيات المنصة من منظور المشترين، البائعين، الكراجات، أو المشرفين:
                  </p>

                  <div className="grid grid-cols-1 gap-2">
                    {ROLES_CONFIG.map((rc) => {
                      const isCurrent = activeRole === rc.role;
                      return (
                        <button
                          key={rc.role}
                          type="button"
                          onClick={() => handleSelectRole(rc.role)}
                          className={`w-full text-right p-3 rounded-xl border text-xs transition-all flex items-center justify-between cursor-pointer ${
                            isCurrent
                              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                              : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                          }`}
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-black text-xs">{rc.title}</span>
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${
                                  isCurrent
                                    ? 'bg-amber-400 text-slate-950'
                                    : 'bg-slate-100 text-slate-600'
                                }`}
                              >
                                {rc.badge}
                              </span>
                            </div>
                            <span
                              className={`text-[10px] block mt-0.5 line-clamp-1 ${
                                isCurrent ? 'text-slate-300' : 'text-slate-500'
                              }`}
                            >
                              {rc.desc}
                            </span>
                          </div>

                          {isCurrent && (
                            <Check className="w-4 h-4 text-amber-400 shrink-0 mr-2" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Section 3: Quick Tools & Utilities */}
                <div>
                  <h3 className="text-xs font-black text-slate-900 mb-3 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-slate-700" />
                    <span>أدوات مساعدة وإعدادات النظام</span>
                  </h3>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {/* Push Notifications Settings */}
                    {onOpenPushModal && (
                      <button
                        type="button"
                        onClick={() => {
                          onOpenPushModal();
                          setIsMenuOpen(false);
                        }}
                        className="p-3 bg-white hover:bg-amber-50/50 border border-slate-200 hover:border-amber-300 rounded-xl text-right transition-colors cursor-pointer flex flex-col justify-between"
                      >
                        <BellRing className="w-4 h-4 text-amber-600 mb-1" />
                        <div>
                          <span className="font-bold text-slate-900 block">إشعارات المتصفح</span>
                          <span className="text-[10px] text-slate-500 block">دفع فوري عبر Service Worker</span>
                        </div>
                      </button>
                    )}

                    {/* Help Center */}
                    {onOpenHelpCenter && (
                      <button
                        type="button"
                        data-testid="help-center-btn"
                        onClick={() => {
                          onOpenHelpCenter();
                          setIsMenuOpen(false);
                        }}
                        className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-right transition-colors cursor-pointer flex flex-col justify-between"
                      >
                        <HelpCircle className="w-4 h-4 text-amber-600 mb-1" />
                        <div>
                          <span className="font-bold text-slate-900 block">مركز المساعدة</span>
                          <span className="text-[10px] text-slate-500 block">دليل الاستخدام والـ FAQ</span>
                        </div>
                      </button>
                    )}

                    {/* SQL DDL Schema */}
                    <button
                      type="button"
                      onClick={() => {
                        onOpenSqlModal();
                        setIsMenuOpen(false);
                      }}
                      className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-right transition-colors cursor-pointer flex flex-col justify-between"
                    >
                      <Database className="w-4 h-4 text-blue-600 mb-1" />
                      <div>
                        <span className="font-bold text-slate-900 block">مخطط SQL DDL</span>
                        <span className="text-[10px] text-slate-500 block">بوستغريس ووثائق الجداول</span>
                      </div>
                    </button>

                    {/* Language Switch */}
                    {onToggleLanguage && (
                      <button
                        type="button"
                        onClick={onToggleLanguage}
                        className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-right transition-colors cursor-pointer flex flex-col justify-between"
                      >
                        <Languages className="w-4 h-4 text-emerald-600 mb-1" />
                        <div>
                          <span className="font-bold text-slate-900 block">لغة العرض</span>
                          <span className="text-[10px] text-slate-500 block font-mono">
                            {language === 'ar' ? 'العربية (تبديل إلى EN)' : 'English (Switch to AR)'}
                          </span>
                        </div>
                      </button>
                    )}

                    {/* Reset Data */}
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm('هل تود إعادة تعيين كافة البيانات إلى الحالة الافتراضية لمنطقة السويداء والكفر؟')) {
                          onResetData();
                          setIsMenuOpen(false);
                        }
                      }}
                      className="p-3 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-xl text-right transition-colors cursor-pointer flex flex-col justify-between"
                    >
                      <RefreshCw className="w-4 h-4 text-rose-600 mb-1" />
                      <div>
                        <span className="font-bold text-rose-900 block">إعادة التهيئة</span>
                        <span className="text-[10px] text-rose-600 block">استرجاع بيانات البذور الأصلية</span>
                      </div>
                    </button>
                  </div>
                </div>

              </div>

              {/* Drawer Footer Bar */}
              <div className="p-4 bg-slate-50 border-t border-slate-200 shrink-0 flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1.5 text-[11px]">
                  <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>السويداء · الكفر · صلخد · شهبا</span>
                </span>
                <button
                  type="button"
                  onClick={() => setIsMenuOpen(false)}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-lg transition-colors cursor-pointer text-[11px]"
                >
                  إغلاق القائمة
                </button>
              </div>

            </div>
          </div>
        </div>
      )}
    </>
  );
};
